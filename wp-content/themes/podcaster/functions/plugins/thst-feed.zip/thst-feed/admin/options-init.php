<?php

    /**
     * For full documentation, please visit: http://docs.reduxframework.com/
     * For a more extensive sample-config file, you may look at:
     * https://github.com/reduxframework/redux-framework/blob/master/sample/sample-config.php
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "thst-pod-feed";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.
    $plugin_options_img = dirname( __FILE__ );
    $pluginurl = plugins_url().'/thst-feed/img';
    
    /* Plugin Version */
    //define(WP_PLUGIN_DIR, $pluginconstant);
    $plugin_path = thst_feed_path();
    $plugin_data = get_plugin_data($plugin_path, $markup = true, $translate = true );

    /* Custom Vlidation */
    /**
     * Custom function for the callback validation referenced above
     **/
    if (!function_exists('pod_taken_feed_names')):
     
        function pod_taken_feed_names($field, $value, $existing_value) {
            $error = false;
            $taken_feeds = array( 'feed', 'rss', 'rss2', 'rdf', 'atom', 'comments-feed', 'comments-rss', 'comments-rss2', 'comments-atom' );    
            
            if( ! in_array( $value, $taken_feeds ) ) {
                $value = $value;
                $value = str_replace(' ', '-', $value);
            } else {
                $error = true;
                $value = $existing_value;
                $field['msg'] = __('The feed name you submitted is a WordPress default and already taken. Please chhoose a different name.','thstlang');
            }            
            
            $return['value'] = $value;
            if ($error == true) {
                $return['error'] = $field;
            }
            return $return;
        }
     
    endif;

    $args = array(
        'opt_name' => 'thst-pod-feed',
        'display_name' => $plugin_data['Name'],
        'display_version' => $plugin_data['Version'],
        'page_title' => $plugin_data['Name'],
        'update_notice' => TRUE,
        'menu_type' => 'menu',
        'dev_mode'          => false,
        'menu_icon' => $pluginurl.'/icon.png', // Specify a custom URL to an icon
        'menu_title' => 'Podcasting Feed',
        'allow_sub_menu' => false,
        'open_expanded'     => true,
        'page_priority'     => null,                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'       => 'plugins.php',            // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'  => 'manage_options',        // Permissions needed to access the options panel.
        'page_slug'         => 'thst-feed-options',              // Page slug used to denote the panel
        'save_defaults'     => true,                    // On load save the defaults to DB before user clicks save or not
        'default_show'      => false,                   // If true, shows the default value next to each field that is not the default value.
        'show_import_export' => false,
        'default_mark' => '',
        'hints' => array(
            'icon_position' => 'right',
            'icon_color' => 'lightgray',
            'icon_size' => 'normal',
            'tip_style' => array(
                'color' => 'light',
            ),
            'tip_position' => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect' => array(
                'show' => array(
                    'duration' => '500',
                    'event' => 'mouseover',
                ),
                'hide' => array(
                    'duration' => '500',
                    'event' => 'mouseleave unfocus',
                ),
            ),
        ),
        'output' => TRUE,
        'output_tag' => TRUE,
        'settings_api' => TRUE,
        'cdn_check_time' => '1440',
        'compiler' => TRUE,
        'save_defaults' => TRUE,
        'database' => 'options',
        'transient_time' => '3600',
        'network_sites' => TRUE,
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://twitter.com/themestationco',
        'title' => 'Follow Theme Staion on Twitter',
        'icon'  => 'el el-twitter'
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'admin_folder' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'admin_folder' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'admin_folder' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'admin_folder' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'admin_folder' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    Redux::setSection( $opt_name, array(
        'title'  => __( 'General Feed Settings', 'redux-framework-demo' ),
        'id'     => 'thst-pod-general-feed',
        'icon'   => 'el el-home',
        'fields' => array(
            array(
                        'id'        => 'thst-pod-category',
                        'type'      => 'select',
                        'data'      => 'categories',
                        'title'     => __('Podcast Category', 'thstlang'),
                        'subtitle'  => __('Which category is your podcast filed into?', 'thstlang'),
                        'desc'      => __('Please select the category from the drop-down menu.', 'thstlang'),
                    ),
                    array(
                        'id'        => 'thst-pod-feedname',
                        'type'      => 'text',
                        'title'     => __('Feed Name', 'thstlang'),
                        'subtitle'  => __('Do you want to define your own feed name?', 'thstlang'),
                        'desc'      => __('Please type your feed name into the text field. Your feed URL is '.get_bloginfo('url').'/?feed=<em>yourfeedname</em>.', 'thstlang'),

                        'validate_callback' => 'pod_taken_feed_names',
                        'default'   => 'podcast',
                    ),
                    
                    array(
                        'id'       => 'thst-channel-settings-title',
                        'type'     => 'raw',
                        'title'    => __('<h3>iTunes Channel Settings</h3>', 'thstlang'),
                        'content' => __('The settings below are are going to be used for your iTunes compatible feed.', 'thstlang'),
                    ),
                    array(
                        'id'        => 'thst-pod-channel-title',
                        'type'      => 'text',
                        'title'     => __('iTunes Channel Title', 'thstlang'),
                        'subtitle'  => __('Submit your channel title.', 'thstlang'),
                        'desc'      => __('Please type your channel title into the text field. Leave it blank if you would like to use your blog title.', 'thstlang'),
                        'validate'  => 'no_html',
                        'default'   => '',
                    ),
                    array(
                        'id'        => 'thst-pod-channel-author',
                        'type'      => 'text',
                        'title'     => __('iTune Channel Author', 'thstlang'),
                        'subtitle'  => __('Submit your channel author.', 'thstlang'),
                        'desc'      => __('Please type your channel author into the text field. Leave it blank if you would like to use your WordPress user name', 'thstlang'),
                        'validate'  => 'no_html',
                        'default'   => '',
                    ),
                    array(
                        'id'        => 'thst-pod-channel-website',
                        'type'      => 'text',
                        'title'     => __('Website', 'thstlang'),
                        'subtitle'  => __('Submit your website URL. This is the adress that will be displayed on your iTunes profile.', 'thstlang'),
                        'desc'      => __('Please type the URL of your website into the text field.', 'thstlang'),
                        'validate'  => 'url',
                        'default'   => '',
                    ),
                    array(
                        'id' => 'thst-pod-itunes-icon',
                        'type' => 'media',
                        'title' => __('iTunes User Image', 'thstlang'),
                        'subtitle' => __('Would you like to upload a user image?', 'thstlang'),
                        'desc' => __('Upload a user image here, that will be used in your iTunes compatible feed. It will also be used within your podcast in the iTunes store.', 'thstlang'),
                        'placeholder' => $plugin_options_img. '/img/header.jpg'
                    ),
                    array(
                        'id'=>'thst-pod-itunes-description',
                        'type' => 'textarea',
                        'title' => __('iTunes Podcast Description', 'redux-framework-demo'),
                        'subtitle' => __('Would you like to provide an iTunes description for your podcast?', 'redux-framework-demo'),
                        'desc' => __('Type your description into the text area. HTML is not allowed.', 'redux-framework-demo'),
                        'validate' => 'no_html',
                        'default' => '',
                    ),
                    array(
                        'id'       => 'thst-title-settings-title-2',
                        'type'     => 'raw',
                        'title'    => __('<h3>iTunes Feed Settings</h3>', 'redux-framework-demo'),
                        'content' => __('The settings below are are going to be used for your iTunes compatible feed.', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'thst-pod-feedlang',
                        'type'     => 'select',
                        'title'     => __('Feed Language', 'thstlang'),
                        'subtitle'  => __('What is the language of your podcas/feed?', 'thstlang'),
                        'desc'      => __('Please select your language from the drop down menu.', 'thstlang'),
                        'options'  => array(
                            'af' => 'Afrikaans',
                            'sq' => 'Albanian',
                            'eu' => 'Basque',
                            'be' => 'Belarusian',
                            'bg' => 'Bulgarian',
                            'ca' => 'Catalan',
                            'zh-cn' => 'Chinese (Simplified)',
                            'zh-tw' => 'Chinese (Traditional)',
                            'hr' => 'Croatian',
                            'cs' => 'Czech',
                            'da' => 'Danish',
                            'nl' => 'Dutch',
                            'nl-be' => 'Dutch (Belgium)',
                            'nl-nl' => 'Dutch (Netherlands)',
                            'en' => 'English',
                            'en-au' => 'English (Australia)',
                            'en-bz' => 'English (Belize)',
                            'en-ca' => 'English (Canada)',
                            'en-ie' => 'English (Ireland)',
                            'en-jm' => 'English (Jamaica)',
                            'en-nz' => 'English (New Zealand)',
                            'en-ph' => 'English (Phillipines)',
                            'en-za' => 'English (South Africa)',
                            'en-tt' => 'English (Trinidad)',
                            'en-gb' => 'English (United Kingdom)',
                            'en-us' => 'English (United States)',
                            'en-zw' => 'English (Zimbabwe)',
                            'et' => 'Estonian',
                            'fo' => 'Faeroese',
                            'fi' => 'Finnish',
                            'fr' => 'French',
                            'fr-be' => 'French (Belgium)',
                            'fr-ca' => 'French (Canada)',
                            'fr-fr' => 'French (France)',
                            'fr-lu' => 'French (Luxembourg)',
                            'fr-mc' => 'French (Monaco)',
                            'fr-ch' => 'French (Switzerland)',
                            'gl' => 'Galician',
                            'gd' => 'Gaelic',
                            'de' => 'German',
                            'de-at' => 'German (Austria)',
                            'de-de' => 'German (Germany)',
                            'de-li' => 'German (Liechtenstein)',
                            'de-lu' => 'German (Luxembourg)',
                            'de-ch' => 'German (Switzerland)',
                            'el' => 'Greek',
                            'haw' => 'Hawaiian',
                            'hu' => 'Hungarian',
                            'is' => 'Icelandic',
                            'in' => 'Indonesian',
                            'ga' => 'Irish',
                            'it' => 'Italian',
                            'it-it' => 'Italian (Italy)',
                            'it-ch' => 'Italian (Switzerland)',
                            'ja' => 'Japanese',
                            'ko' => 'Korean',
                            'mk' => 'Macedonian',
                            'no' => 'Norwegian',
                            'pl' => 'Polish',
                            'pt' => 'Portuguese',
                            'pt-br' => 'Portuguese (Brazil)',
                            'pt-pt' => 'Portuguese (Portugal)',
                            'ro' => 'Romanian',
                            'ro-mo' => 'Romanian (Moldova)',
                            'ro-ro' => 'Romanian (Romania)',
                            'ru' => 'Russian',
                            'ru-mo' => 'Russian (Moldova)',
                            'ru-ru' => 'Russian (Russia)',
                            'sr' => 'Serbian',
                            'sk' => 'Slovak',
                            'sl' => 'Slovenian',
                            'es' => 'Spanish',
                            'es-ar' => 'Spanish (Argentina)',
                            'es-bo' => 'Spanish (Bolivia)',
                            'es-cl' => 'Spanish (Chile)',
                            'es-co' => 'Spanish (Colombia)',
                            'es-cr' => 'Spanish (Costa Rica)',
                            'es-do' => 'Spanish (Dominican Republic)',
                            'es-ec' => 'Spanish (Ecuador)',
                            'es-el' => 'Spanish (El Salvador)',
                            'es-gt' => 'Spanish (Guatemala)',
                            'es-hn' => 'Spanish (Honduras)',
                            'es-mx' => 'Spanish (Mexico)',
                            'es-ni' => 'Spanish (Nicaragua)',
                            'es-pa' => 'Spanish (Panama)',
                            'es-py' => 'Spanish (Paraguay)',
                            'es-pe' => 'Spanish (Peru)',
                            'es-pr' => 'Spanish (Puerto Rico)',
                            'es-es' => 'Spanish (Spain)',
                            'es-uy' => 'Spanish (Uruguay)',
                            'es-ve' => 'Spanish (Venezuela)',
                            'sv' => 'Swedish',
                            'sv-fi' => 'Swedish (Finland)',
                            'sv-se' => 'Swedish (Sweden)',
                            'tr' => 'Turkish',
                            'uk' => 'Ukranian',
                        ),
                        'default'  => 'en-gb',
                    ),
                    array(
                        'id' => 'thst-pod-itunes-cat',
                        'type' => 'text',
                        'title' => __('iTunes Category', 'thstlang'),
                        'subtitle' => __('What is the iTunes category of your podcast?', 'thstlang'),
                        'desc' => __('Type it in the text field above.', 'thstlang'),
                        'validate' => 'no_html',
                        'placeholder' => 'Technology'
                    ),
                    array(
                        'id' => 'thst-pod-subcat',
                        'type' => 'text',
                        'title' => __('iTunes Subcategory', 'thstlang'),
                        'subtitle' => __('What is your iTunes subcategory?', 'thstlang'),
                        'desc' => __('Type it in the text field above.', 'thstlang'),
                        'validate' => 'no_html',
                        'placeholder' => 'Gadgets'
                    ),
                    array(
                        'id' => 'thst-pod-explicit',
                        'type' => 'button_set',
                        'title' => __('iTunes Explicit Material', 'thstlang'),
                        'subtitle' => __('Is the content of your podcast explicit?', 'thstlang'),
                        'desc' => __('Select either yes or no.', 'thstlang'),
                        'options' => array(
                            'no' => 'No',
                            'yes' => 'Yes'
                         ),
                        'default' => 'no'
                    ),
                    array(
                        'id'       => 'thst-pod-itunes-redirect-title',
                        'type'     => 'raw',
                        'title'    => __('<h3>iTunes Redirect Feed</h3>', 'thstlang'),
                        'content' => __('The settings below are are going to be used for your iTunes compatible feed.', 'redux-framework-demo'),
                    ),
                    array(
                        'id'       => 'thst-pod-itunes-redirect',
                        'type'     => 'switch',
                        'title'    => __('Redirect to new feed', 'thstlang'),
                        'subtitle' => __('Do you wish to send iTunes the URL of your new feed?', 'thstlang'),
                        'desc'      => __('Please turn this switch to on, to send your new URL to iTunes.', 'thstlang'),
                        'default'  => false
                    ),
                    array(
                        'id'        => 'thst-pod-itunes-newfeed',
                        'type'      => 'text',
                        'required'  => array('thst-pod-itunes-redirect', '=' , true),
                        'title'     => __('New Feed URL', 'thstlang'),
                        'subtitle'  => __('Do you have a new feed url?', 'thstlang'),
                        'desc'      => __('Please type your new feed url into the text field. This information will be sent to iTunes to update your URL.', 'thstlang'),
                        'validate'  => 'url',
                        'default'   => '',
                    ),
                    array(
                        'id'       => 'thst-pod-audio-player-title',
                        'type'     => 'raw',
                        'title'    => __('<h3>Media Players</h3>', 'thstlang'),
                        'content' => __('Only activate this section, if you are <strong><em>NOT</em></strong> using Podcaster.', 'thstlang'),
                    ),
                    array(
                        'id' => 'thst-pod-theme-active',
                        'type' => 'button_set',
                        'title' => __('Theme', 'thstlang'),
                        'subtitle' => __('Is Podcaster active?', 'thstlang'),
                        'desc' => __('Select whether Podcaster theme is active or not.', 'thstlang'),
                        'options' => array(
                            'pod_active' => 'Podcaster active',
                            'pod_inactive' => 'Podcaster inactive'
                         ),
                        'default' => 'pod_active'
                    ),
                    array(
                        'id'       => 'thst-pod-theme-players',
                        'type'     => 'switch',
                        'required' => array( 'thst-pod-theme-active', '=', 'pod_inactive' ),
                        'title'    => __('Display Audio/Video Players', 'thstlang'),
                        'subtitle' => __('Do you wish to display audio/video players?', 'thstlang'),
                        'desc'      => __('This switch to on, to display audio/video players in your posts.', 'thstlang'),
                        'default'  => false
                    ),
                    array(
                        'id'       => 'thst-pod-theme-players-sinlge',
                        'type'     => 'switch',
                        'required' => array( 'thst-pod-theme-players', '=', true ),
                        'title'    => __('Display Single Post Only', 'thstlang'),
                        'subtitle' => __('Do you wish to display audio/video players on single post pages only?', 'thstlang'),
                        'desc'      => __('Turn this switch to on, to display audio/video players in your single post pages only.', 'thstlang'),
                        'default'  => false
                    ),

        )
    ) );

    /*
     * <--- END SECTIONS
     */