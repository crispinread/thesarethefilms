<?php
/* Plugin Name: Theme Station Podcasting Feed
 * Plugin URI: http://www.themestation.co/plugins
 * Description: Create a feed for your podcast that is iTunes compatible.
 * Version: 1.4
 * Author: Theme Station
 * Author URI: http://www.themestation.co
 */

/* Updates your plugin. */
if( ! function_exists('thst_rss_update') ){
    function thst_rss_update() {
        require 'update-checker/plugin-update-checker.php';
        $MyUpdateChecker = PucFactory::buildUpdateChecker(
        'http://themestation.co/update/?action=get_metadata&slug=thst-feed', //Metadata URL.
        __FILE__, //Full path to the main plugin file.
        'thst-feed' //Plugin slug. Usually it's the same as the name of the directory.
        );
    }
}
add_action( 'plugins_loaded', 'thst_rss_update' );

/* Plugin Path*/
if( ! function_exists( 'thst_feed_path' ) ){
    function thst_feed_path() {
        $output = plugin_dir_path( __FILE__ ).'thst-feed.php';
        return $output;
    }
}

/* This plugin uses Redux Theme Options to manage plugin settings. We'll include it here.*/
require_once( dirname( __FILE__ ) . '/admin/admin-init.php' );


/* Creates iTunes compatible custom RSS feed. */
add_action('init', 'thstRSS_Plugin');
if( ! function_exists('thstRSS_Plugin') ) {
    function thstRSS_Plugin(){
    	$options = get_option('thst-pod-feed');  
    	$thst_pod_feedname = isset( $options['thst-pod-feedname'] ) ? $options['thst-pod-feedname'] : '';

        add_feed($thst_pod_feedname, 'thstRSSFunction_Plugin');
    }
}

if( ! function_exists('thst_get_attachment_id_by_src') ) {
    function thst_get_attachment_id_by_src($image_src) {
        global $wpdb;

        $query = "SELECT ID FROM $wpdb->posts WHERE guid='$image_src'";
        $id = $wpdb->get_var($query);
        return $id;
    }
}

if( ! function_exists('rdo_flexible_excerpt') ) {
	function thst_get_rss_excerpt($post_id,$limit=25){
		if( $limit == '' ) $limit = 25;
			$limit = intval($limit);

			$post_object = get_post( $post_id );
			$get_the_content = $post_object->post_content;
			$get_the_excerpt = $post_object->post_excerpt;

			if( $get_the_excerpt == '' ){
				$get_the_content = mb_substr( strip_tags($get_the_content) ,0  );
				$excerpt = explode(' ', $get_the_content, $limit);

				array_pop($excerpt);
				$excerpt = implode(" ",$excerpt).' ...';

				$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
			} else {
				$excerpt = $get_the_excerpt;
			}
			

		  	return $excerpt;
	}
}

if( ! function_exists('thst_podcaster_get_players') ){
    function thst_podcaster_get_players($content) {
        global $post;
        $theme = wp_get_theme(); 
        $format = get_post_format();

        $options = get_option('thst-pod-feed');
        $thst_pod_theme_player = isset( $options['thst-pod-theme-players'] ) ? $options['thst-pod-theme-players'] : '';
        $thst_pod_theme_active = isset( $options['thst-pod-theme-active'] ) ? $options['thst-pod-theme-active'] : '';
        $thst_pod_theme_players_sinlge = isset( $options['thst-pod-theme-players-sinlge'] ) ? $options['thst-pod-theme-players-sinlge'] : '';
        
        if( $thst_pod_theme_active == 'pod_inactive' && $thst_pod_theme_player == true ) {
            if ( 'Podcaster' != $theme->name && 'podcaster' != $theme->name && 'Podcaster Child Theme' != $theme->name &&  'podcaster child theme' != $theme->name ) {

                $output = '';

                if( $format == 'audio' ) {
                    $audiourl = get_post_meta( $post->ID, 'cmb_thst_audio_url', true );
                    $audioid = get_post_meta( $post->ID, 'cmb_thst_audio_url_id', true );
                    $audioembed = get_post_meta( $post->ID, 'cmb_thst_audio_embed', true );
                    $audioembedcode = get_post_meta( $post->ID, 'cmb_thst_audio_embed_code', true );
                    $audiocapt = get_post_meta($post->ID, 'cmb_thst_audio_capt', true );
                    $audioplists = get_post_meta( $post->ID, 'cmb_thst_audio_playlist', true );
                    $audioex = get_post_meta( $post->ID, 'cmb_thst_audio_explicit', true );



                    $output .= '<div class="audio">';
                    if( $audioembed != '' ) {
                        $au_embedcode = wp_oembed_get( $audioembed );
                        $output .= '<div class="audio_player au_oembed">' . $au_embedcode . '</div><!--audio_player-->';
                    }
                    if( $audiourl != '' ) {
                        $output .= '<div class="audio_player">' . do_shortcode('[audio src="' .$audiourl. '"][/audio]</div><!--audio_player-->'); 
                    }
                    if( is_array( $audioplists ) ) {
                        $output .= do_shortcode('[playlist type="audio" ids="'.implode(',', array_keys($audioplists)).'"][/playlist]');
                    } 
                    if ( $audioembedcode != '') {
                        $output .= '<div class="audio_player embed_code">' . $audioembedcode . '</div><!--audio_player-->';
                    }                             
                    $output .= '</div><!-- .audio -->';
                } elseif( $format == 'video' ) {
                    $videoembed = get_post_meta( $post->ID, 'cmb_thst_video_embed', true);
                    $videourl =  get_post_meta( $post->ID, 'cmb_thst_video_url', true);
                    $videocapt = get_post_meta($post->ID, 'cmb_thst_video_capt', true);
                    $videothumb = get_post_meta($post->ID, 'cmb_thst_video_thumb',true);
                    $videoplists = get_post_meta( $post->ID, 'cmb_thst_video_playlist', true );
                    $videoembedcode = get_post_meta( $post->ID, 'cmb_thst_video_embed_code', true );
                    $videoex = get_post_meta( $post->ID, 'cmb_thst_video_explicit', true );

                    if( $videoembed != '' ) {
                        $output .= '<div class="video_player">' . wp_oembed_get($videoembed) . '</div><!--video_player-->';
                    }
                    if( $videourl != '' ) {
                        $output .= '<div class="video_player">' . do_shortcode('[video poster="' .$videothumb. '" src="' .$videourl. '"][/video]') .'</div><!--video_player-->';
                    }
                    if( is_array( $videoplists ) ) {
                        $output .=  do_shortcode('[playlist type="video" ids="'.implode(',', array_keys($videoplists)).'"][/playlist]');
                    }
                    if( $videoembedcode !='' ) {
                        $output .= '<div class="video_player">' . $videoembedcode . '</div><!--video_player-->';
                    }
                }
            }

            if( $thst_pod_theme_players_sinlge == true ) {
                if( is_single() ) {
                    $content .= $output;
                } else {
                    $content .= '';
                }
            } else {
                $content .= $output;
            }
        }
        
        return $content;
    }
}
add_filter( 'the_content', 'thst_podcaster_get_players' );



/* This is your iTunes compatible RSS feed. */
if( ! function_exists('thstRSSFunction_Plugin') ) {
    function thstRSSFunction_Plugin(){
        header('Content-Type: '.feed_content_type('rss-http').'; charset='.get_option('blog_charset'), true);
        echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>';
        ?>
        <rss version="2.0"
            xmlns:content="http://purl.org/rss/1.0/modules/content/"
            xmlns:wfw="http://wellformedweb.org/CommentAPI/"
            xmlns:dc="http://purl.org/dc/elements/1.1/"
            xmlns:atom="http://www.w3.org/2005/Atom"
            xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
            xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
            xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"
            <?php do_action('rss2_ns'); ?>>
        <channel>
            <?php 
                    $options = get_option('thst-pod-feed');
                    $arch_category = isset( $options['thst-pod-category'] ) ? $options['thst-pod-category'] : '';
                    $pod_itunes_channel_title = isset( $options['thst-pod-channel-title'] ) ? $options['thst-pod-channel-title'] : '';
                    $pod_itunes_channel_author = isset( $options['thst-pod-channel-author'] ) ? $options['thst-pod-channel-author'] : '';
                    $pod_itunes_channel_website = isset( $options['thst-pod-channel-website'] ) ? $options['thst-pod-channel-website'] : '';
                    $pod_itunes_icon = isset( $options['thst-pod-itunes-icon'] ) ? $options['thst-pod-itunes-icon'] : '';
                    $pod_itunes_icon_img = isset( $pod_itunes_icon['url'] ) ? $pod_itunes_icon['url'] : '';
                    $pod_itunes_cat = isset( $options['thst-pod-itunes-cat'] ) ? $options['thst-pod-itunes-cat'] : '';
                    $pod_itunes_subcat = isset( $options['thst-pod-subcat'] ) ? $options['thst-pod-subcat'] : '';
                    $pod_itunes_explicit = isset( $options['thst-pod-explicit'] ) ? $options['thst-pod-explicit'] : '';
                    $pod_itunes_desc = isset( $options['thst-pod-itunes-description'] ) ? $options['thst-pod-itunes-description'] : ''; 
    				$pod_itunes_redirect = isset( $options['thst-pod-itunes-redirect'] ) ? $options['thst-pod-itunes-redirect'] : ''; 
                    $pod_itunes_new_feed_url = isset( $options['thst-pod-itunes-newfeed'] ) ? $options['thst-pod-itunes-newfeed'] : ''; 
                    $pod_itunes_lang = isset( $options['thst-pod-feedlang'] ) ? $options['thst-pod-feedlang'] : '';

                    $rss_title = get_bloginfo('name');
                    $rss_description = get_bloginfo('description');
                    $rss_url = get_bloginfo('url');
                    $rss_language = substr(get_bloginfo('language'), 0, 2);
                    $rss_language = $pod_itunes_lang;
                    $rss_author = get_bloginfo( 'name' );
                    $rss_email = get_option('admin_email');
                ?>
                <title><?php if ( $pod_itunes_channel_title !='' ) { echo esc_html( $pod_itunes_channel_title ); } else { echo esc_html( $rss_title ); } ?></title>
                <atom:link href="<?php esc_url( self_link() ); ?>" rel="self" type="application/rss+xml" />
                <link><?php if( $pod_itunes_channel_website !='') { echo esc_url( $pod_itunes_channel_website ); } else { echo esc_url( $rss_url ); } ?></link>
                <description><?php echo esc_html( $pod_itunes_desc ); ?></description>
                <lastBuildDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_lastpostmodified('GMT'), false); ?></lastBuildDate>
                <language><?php echo esc_html( $rss_language ); ?></language>
                <copyright>&#x2117; &amp; &#xA9; <?php echo date("Y") ?> <?php if ( $pod_itunes_channel_author != '' ){ echo $pod_itunes_channel_author; } else { echo $rss_author; } ?></copyright>

                <itunes:subtitle><?php echo esc_html( $rss_description ); ?></itunes:subtitle>
                <itunes:author><?php if( $pod_itunes_channel_author !='' ) { echo esc_html( $pod_itunes_channel_author ); } else { echo esc_html( $rss_author ); } ?></itunes:author>
                <itunes:owner>
                        <itunes:name><?php echo esc_html( $rss_author ); ?></itunes:name>
                        <itunes:email><?php echo esc_html( $rss_email ); ?></itunes:email>
                </itunes:owner>

                <?php if( $pod_itunes_icon_img !='' ) : ?>
                <itunes:image href="<?php echo $pod_itunes_icon_img; ?>" />
                <image>
                        <url><?php echo $pod_itunes_icon_img; ?></url>
                        <title><?php if ( $pod_itunes_channel_title !='' ) { echo esc_html( $pod_itunes_channel_title ); } else { echo esc_html( $rss_title ); } ?></title>
                        <link><?php echo esc_url( $rss_url ); ?></link>
                </image>
                <?php endif; ?>

                <itunes:explicit><?php echo esc_html( $pod_itunes_explicit ); ?></itunes:explicit>

                <?php if( $pod_itunes_cat != '' || $pod_itunes_subcat !='' ) : ?>
                    <?php if( $pod_itunes_cat !='' ) : ?>
                    <itunes:category text="<?php echo esc_html( $pod_itunes_cat ); ?>">
                    <?php endif; ?>
                    <?php if( $pod_itunes_subcat !='' ) : ?>
                    <itunes:category text="<?php echo esc_html( $pod_itunes_subcat ); ?>"/>
                    <?php endif; ?>
                    </itunes:category>
                <?php endif; ?>

    			<?php if( $pod_itunes_redirect == true ) : ?>
                    <itunes:new-feed-url><?php echo esc_url( $pod_itunes_new_feed_url ); ?></itunes:new-feed-url>
                <?php endif; ?>

                <sy:updatePeriod><?php echo apply_filters( 'rss_update_period', 'hourly' ); ?></sy:updatePeriod>
                <sy:updateFrequency><?php echo apply_filters( 'rss_update_frequency', '1' ); ?></sy:updateFrequency>

                <?php do_action('rss2_head'); ?>
                <?php 
                $rss_posts = get_option('posts_per_rss');

                if( isset( $arch_category ) ) {
                        $args = array(
                                'post_type' => 'post',
                                'cat' => $arch_category,
                                'post_status' => 'publish',
                                'posts_per_page' => $rss_posts
                        );
                } else {
                        $args = array(
                                'post_type' => 'post',
                                'post_status' => 'publish',
                                'posts_per_page' => $rss_posts
                        );
                }

                $rssquery = new WP_Query( $args );
                if( $rssquery->have_posts() ) :
                    while( $rssquery->have_posts()) : $rssquery->the_post();
                    $format = get_post_format();
                    global $post;

                    if ( $format == "audio" ) {
                            $audiourl = get_post_meta( $post->ID, 'cmb_thst_audio_url', true );
                            $audioplists = get_post_meta( $post->ID, 'cmb_thst_audio_playlist', true );
                    }
                    if ( $format == "video" ) {
                            $videourl = get_post_meta( $post->ID, 'cmb_thst_video_url', true );
                            $videoplists = get_post_meta( $post->ID, 'cmb_thst_video_playlist', true );
                    } ?>
                    <item>
                    <?php 
                        $rss_item_title = get_the_title_rss();
                        $rss_item_excerpt = thst_get_rss_excerpt($post->ID, 100);
                        $rss_item_permalink = get_permalink($post->ID);
                        $rss_item_author = get_the_author();
                                    
                        if ( $format == "audio" ){
                           $rss_explicit_audio = get_post_meta($post->ID, 'cmb_thst_audio_explicit', true);
                            if( $rss_explicit_audio && $rss_explicit_audio == 'on' ) {
                                $rss_flag = 'Yes';
                            } else {
                                $rss_flag = 'No';
                            }
                        } else {
                            $rss_explicit_video = get_post_meta($post->ID, 'cmb_thst_video_explicit', true);
                            if( $rss_explicit_video && $rss_explicit_video == 'on' ) {
                                $rss_flag = 'Yes';
                            } else {
                                $rss_flag = 'No';
                            }
                        }
                        $tobereplaced = array("&nbsp;", "&hellip;");
                        $replacement = array(" ", "...");

                        $rss_excerpt = str_replace( $tobereplaced, $replacement, $rss_item_excerpt ); ?>
                        <title><?php echo esc_html( $rss_item_title ); ?></title>
                        <itunes:summary><![CDATA[<?php echo esc_html( $rss_excerpt); ?>]]></itunes:summary>
 
                        <?php if ( has_post_thumbnail( $post->ID ) ): ?>    
                        <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'square' ); ?>
                        <itunes:image href="<?php echo $image[0]; ?>" />
                        <?php endif ; ?>
                        <link><?php echo esc_html( $rss_item_permalink ); ?></link>
                        <pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
                        <dc:creator><?php echo esc_html( $rss_item_author ); ?></dc:creator>
                        <guid isPermaLink="false"><?php esc_html( the_guid() ); ?></guid>
                        <description><![CDATA[<?php echo $rss_excerpt; ?>]]></description>
                        <content:encoded><![CDATA[<?php echo $rss_excerpt; ?>]]></content:encoded>


                        <?php if ( $format == "audio" ){ ?>
                            <?php if( $audiourl != '' ) { ?>
                            <?php 
                                $audio_id = thst_get_attachment_id_by_src($audiourl);
                                $audiometa = wp_get_attachment_metadata( $audio_id, false );

                                $audiolength = isset( $audiometa['filesize'] ) ? $audiometa['filesize'] : '';
                                $audiolength_formatted = isset( $audiometa['length_formatted'] ) ? $audiometa['length_formatted'] : '';
                            ?>
                            <?php if( $audiolength !='' ) : ?>
                                <enclosure url="<?php echo $audiourl; ?>" length="<?php echo $audiolength; ?>" type="audio/mpeg"></enclosure>
                            <?php else: ?>
                                <enclosure url="<?php echo $audiourl; ?>" length="1" type="audio/mpeg"></enclosure>
                            <?php endif; ?>
                            <?php if( $audiolength_formatted != '' ) : ?>
                                <itunes:duration><?php echo $audiolength_formatted; ?></itunes:duration>
                            <?php endif; ?>
                            <?php } elseif( is_array( $audioplists ) ) { ?>
                                <?php 
                                    $max_loop=1; //This is the desired value of Looping
                                    $count = 0; //First we set the count to be zero ?>
                                <?php foreach ($audioplists as $valuesKey => $value) {
                                    $audio_id = thst_get_attachment_id_by_src($value);
                                    $audiometa = wp_get_attachment_metadata( $audio_id, false );
                                    $audiolength = isset( $audiometa['filesize'] ) ? $audiometa['filesize'] : '';
                                    $audiolength_formatted = isset( $audiometa['length_formatted'] ) ? $audiometa['length_formatted'] : '';

                                    if ( $audiolength != '' ) {
                                        echo '<enclosure url="' .$value. '" length="' .$audiolength. '" type="audio/mpeg"></enclosure>';
                                    } else {
                                        echo '<enclosure url="' .$value. '" length="1" type="audio/mpeg"></enclosure>';
                                    }
                                    if( $audiolength_formatted !='' ) {
	                                	echo '<itunes:duration>' . $audiolength_formatted . '</itunes:duration>';
	                            	}
                                    $count++; //Increase the value of the count by 1
                                    if($count==$max_loop) break; 
                                } ?>
                            <?php } else { ?>
                                <?php rss_enclosure(); ?>
                            <?php } ?>
                                
                        <?php } elseif ( $format == "video" ) { ?>
                                <?php if( $videourl != '' ) { ?>
                                <?php 
                                    $video_id = thst_get_attachment_id_by_src($videourl);
                                    $videometa = wp_get_attachment_metadata( $video_id, false );
                                    $videolength = isset( $videometa['filesize'] ) ? $videometa['filesize'] : '';
                                    $videolength_formatted = isset( $videometa['length_formatted'] ) ? $videometa['length_formatted'] : '';
                                ?>
                                <?php ?>
                                <?php if ( $videolength !='' ) : ?>
                                    <enclosure url="<?php echo $videourl; ?>" length="<?php echo $videolength; ?>" type="video/mpeg"></enclosure>
                                <?php else : ?>
                                    <enclosure url="<?php echo $videourl; ?>" length="1" type="video/mpeg"></enclosure>
                                <?php endif; ?>
                                <?php if( $videolength_formatted != '' ) : ?>
	                                <itunes:duration><?php echo $videolength_formatted; ?></itunes:duration>
	                            <?php endif; ?>
                                <?php } elseif( is_array( $videoplists ) ) { ?>
                                    <?php 
                                        $max_loop=1; //This is the desired value of Looping
                                        $count = 0; //First we set the count to be zero ?>
                                    <?php foreach ($videoplists as $valuesKey => $value) {  
                                        $video_id = thst_get_attachment_id_by_src($value);
                                        $videometa = wp_get_attachment_metadata( $video_id, false );
                                        $videolength = isset( $videometa['filesize'] ) ? $videometa['filesize'] : '';
                                    	$videolength_formatted = isset( $videometa['length_formatted'] ) ? $videometa['length_formatted'] : '';
                                        
                                        if( $videolength != '') {
                                            echo '<enclosure url="' .$value. '" length="' .$videolength. '" type="video/mpeg"></enclosure>';
                                        } else {
                                            echo '<enclosure url="' .$value. '" length="1" type="video/mpeg"></enclosure>';
                                        }
                                        if( $videolength_formatted !='' ) {
		                                	echo '<itunes:duration>' . $videolength_formatted . '</itunes:duration>';
		                            	}
                                        $count++; //Increase the value of the count by 1
                                        if($count==$max_loop) break;
                                    } ?>
                                <?php } else { ?>
                                    <?php rss_enclosure(); ?>
                                <?php } ?>
                            <?php } else { ?>
                            <?php rss_enclosure(); ?>
                        <?php } ?>
                        <itunes:explicit><?php echo esc_html( $rss_flag ); ?></itunes:explicit>
                        <itunes:author><?php if ( $pod_itunes_channel_author != '' ){ echo $pod_itunes_channel_author; } else { echo $rss_item_author; } ?></itunes:author>
                        <?php do_action('rss2_item'); ?>
                    </item>
                <?php endwhile; ?>
        <?php endif; ?>
        </channel>
        </rss>
    <?php 
    }
}

?>